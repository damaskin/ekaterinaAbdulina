export const environment = {
  production: true,
  // This is the name of your Telegram bot
  telegramBotName: 'tgTemplate_Bot',
};
