export const firebaseConfig = {
  apiKey: "AIzaSyCT3E36C2n9uEeIEhMqNSqQUlvhJJAmMdE",
  authDomain: "ekaterina-abdulina.firebaseapp.com",
  projectId: "ekaterina-abdulina",
  storageBucket: "ekaterina-abdulina.firebasestorage.app",
  messagingSenderId: "857123851381",
  appId: "1:857123851381:web:adb160d3dcad969880fc3c"
};
